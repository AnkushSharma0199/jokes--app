package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    ImageView Image;
    Button btn;


    String  mURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Image=findViewById(R.id.im2);
       btn=findViewById(R.id.button2);

       loadMeme();
    }

    public void loadMeme(){
       RequestQueue queue = Volley.newRequestQueue(this);
        String url =" https://meme-api.herokuapp.com/gimme";


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,new Response.Listener<JSONObject>()
               {
            @Override
            public void onResponse(JSONObject response) {


                try {

                String url = response.getString("url");
          mURL=url;
                    Glide.with(MainActivity.this).load(url).into(Image);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Network Error",Toast.LENGTH_SHORT).show();

            }
        });
        queue.add(jsonObjectRequest);
    }

    public void shareMeme(View view) {
        Intent intent= new  Intent (Intent.ACTION_SEND);
        intent.setType("text/plain");
      //  String app_url = "";
       intent.putExtra(Intent.EXTRA_TEXT, mURL);
        startActivity(intent);
   }
    public void nextMeme(View view) {

        loadMeme();
    }
}